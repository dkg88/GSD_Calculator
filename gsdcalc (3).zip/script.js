let dronesData = [];
let isMetric = true;

document.addEventListener('DOMContentLoaded', function () {
  fetch('drones.json')
    .then(response => response.json())
    .then(data => {
      dronesData = data;
      populateDroneSelect();
      updateCameraSettings();
    })
    .catch(error => console.error('Error loading drone data:', error));
});

function populateDroneSelect() {
  const droneSelectButton = document.getElementById('drone-select-button');
  const droneSelectMenu = document.getElementById('drone-select-menu');
  droneSelectMenu.innerHTML = '';

  dronesData.sort((a, b) => a.name.localeCompare(b.name));

  dronesData.forEach((drone, index) => {
    const option = document.createElement('div');
    option.classList.add('p-2', 'cursor-pointer');
    option.dataset.index = index;
    option.innerHTML = `<span>${drone.name}</span>`;
    option.addEventListener('click', () => {
      droneSelectButton.innerText = drone.name;
      droneSelectMenu.style.display = 'none';
      updateCameraSettings();
    });
    droneSelectMenu.appendChild(option);
  });

  droneSelectButton.addEventListener('click', () => {
    droneSelectMenu.style.display = 'block';
  });
}

function updateCameraSettings() {
  const selectedIndex = dronesData.findIndex(drone => drone.name === document.getElementById('drone-select-button').innerText);
  const drone = dronesData[selectedIndex];

  if (!drone) return;

  document.getElementById('image-width').value = `${drone.imageWidth} px`;
  document.getElementById('image-height').value = `${drone.imageHeight} px`;
  document.getElementById('sensor-width').value = `${drone.sensorWidth} mm`;
  document.getElementById('sensor-height').value = `${drone.sensorHeight} mm`;
  document.getElementById('focal-length').value = `${drone.focalLength} mm`;
  document.getElementById('megapixels').value = `${drone.megapixels} MP`;

  clearInputs();
}

function calculate() {
  const selectedIndex = document.getElementById('drone-select-button').innerText;
  const drone = dronesData.find(d => d.name === selectedIndex);

  if (!drone) {
    showError("Please select a drone first.");
    return;
  }

  const flightHeightInput = document.getElementById('flight-height');
  const desiredGSDInput = document.getElementById('desired-gsd');

  if (flightHeightInput.value) {
    const gsd = calculateGSD(drone, parseFloat(flightHeightInput.value));
    updateInputValue(desiredGSDInput, gsd, isMetric ? 'cm/px' : 'in/px');
  } else if (desiredGSDInput.value) {
    const flightHeight = calculateFlightHeight(drone, parseFloat(desiredGSDInput.value));
    updateInputValue(flightHeightInput, flightHeight, isMetric ? 'm' : 'ft');
  } else {
    showError("Please enter either Flight Height or GSD.");
  }
}

function calculateGSD(drone, flightHeight) {
  const sensorWidth = drone.sensorWidth;
  const focalLength = drone.focalLength;
  const imageWidth = drone.imageWidth;

  let gsd = (sensorWidth * convertFlightHeight(flightHeight) * 100) / (focalLength * imageWidth);
  return isMetric ? gsd : gsd / 2.54;
}

function calculateFlightHeight(drone, desiredGSD) {
  const sensorWidth = drone.sensorWidth;
  const focalLength = drone.focalLength;
  const imageWidth = drone.imageWidth;

  let gsd = isMetric ? desiredGSD : desiredGSD * 2.54;
  let flightHeight = (gsd * focalLength * imageWidth) / (sensorWidth * 100);
  return isMetric ? flightHeight : flightHeight * 3.28084;
}

function handleInput(event) {
  let value = event.target.value.replace(/[^\d.]/g, '');
  if (value) {
    const numValue = parseFloat(value);
    if (!isNaN(numValue)) {
      event.target.value = numValue;
      calculate();
    }
  }
}

function handleBlur(event) {
  let value = event.target.value;
  if (value) {
    const numValue = parseFloat(value);
    if (!isNaN(numValue)) {
      updateInputValue(event.target, numValue, getUnitForInput(event.target.id));
    }
  }
}

function updateInputValue(inputElement, value, unit) {
  inputElement.value = value.toFixed(2);
  const unitElement = document.getElementById(`${inputElement.id}-unit`);
  if (unitElement) {
    unitElement.textContent = unit;
  }
}

function getUnitForInput(inputId) {
  return inputId === 'flight-height' ? (isMetric ? 'm' : 'ft') : (isMetric ? 'cm/px' : 'in/px');
}

function adjustValue(id, adjustment) {
  const input = document.getElementById(id);
  let value = parseFloat(input.value) || 0;

  if (id === 'flight-height') {
    value = isMetric ? value + adjustment : value + adjustment / 3.28084;
  } else {
    value = Math.max(0, value + adjustment);
  }

  updateInputValue(input, value, getUnitForInput(id));
  calculate();
}

function clearInputs() {
  document.getElementById('flight-height').value = '';
  document.getElementById('desired-gsd').value = '';
  document.getElementById('flight-height-unit').textContent = isMetric ? 'm' : 'ft';
  document.getElementById('desired-gsd-unit').textContent = isMetric ? 'cm/px' : 'in/px';
}

function toggleUnits() {
  isMetric = !isMetric;
  const flightHeightInput = document.getElementById('flight-height');
  const desiredGSDInput = document.getElementById('desired-gsd');

  if (flightHeightInput.value) {
    const flightHeight = parseFloat(flightHeightInput.value);
    updateInputValue(flightHeightInput, isMetric ? flightHeight / 3.28084 : flightHeight * 3.28084, isMetric ? 'm' : 'ft');
  }

  if (desiredGSDInput.value) {
    const desiredGSD = parseFloat(desiredGSDInput.value);
    updateInputValue(desiredGSDInput, isMetric ? desiredGSD * 2.54 : desiredGSD / 2.54, isMetric ? 'cm/px' : 'in/px');
  }

  updatePlaceholders();
  document.getElementById('flight-height-unit').textContent = isMetric ? 'm' : 'ft';
  document.getElementById('desired-gsd-unit').textContent = isMetric ? 'cm/px' : 'in/px';
}

function updatePlaceholders() {
  document.getElementById('flight-height').placeholder = `Enter height in ${isMetric ? 'meters' : 'feet'}`;
  document.getElementById('desired-gsd').placeholder = `Enter GSD in ${isMetric ? 'cm/px' : 'in/px'}`;
}

function showError(message) {
  alert(message);
}

function convertFlightHeight(height) {
  return isMetric ? height : height / 3.28084;
}

// Initialize placeholders
updatePlaceholders();

// Add event listeners
document.getElementById('flight-height').addEventListener('input', handleInput);
document.getElementById('flight-height').addEventListener('blur', handleBlur);
document.getElementById('desired-gsd').addEventListener('input', handleInput);
document.getElementById('desired-gsd').addEventListener('blur', handleBlur);
